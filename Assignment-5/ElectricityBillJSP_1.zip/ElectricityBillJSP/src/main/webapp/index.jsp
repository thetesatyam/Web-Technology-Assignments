<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Electricity Bill Calculator</title>

    <!-- Bootstrap 5 -->
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #e3f2fd, #f8f9fa);
        }

        .main-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px 15px;
        }

        .calculator-card {
            width: 100%;
            max-width: 850px;
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 35px rgba(0, 0, 0, 0.15);
        }

        .header {
            background: linear-gradient(135deg, #0d6efd, #084298);
            color: white;
            padding: 35px;
            text-align: center;
        }

        .header-icon {
            font-size: 50px;
            margin-bottom: 10px;
        }

        .header h1 {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .header p {
            margin: 0;
            opacity: 0.9;
        }

        .content {
            padding: 35px;
        }

        .form-label {
            font-weight: bold;
            color: #333;
        }

        .form-control {
            height: 55px;
            border-radius: 10px;
            font-size: 18px;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.15);
        }

        .rate-box {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            border-left: 5px solid #0d6efd;
        }

        .rate-box h4 {
            color: #0d6efd;
            font-weight: bold;
            margin-bottom: 18px;
        }

        .rate-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #dee2e6;
        }

        .rate-item:last-child {
            border-bottom: none;
        }

        .rate-name {
            color: #555;
        }

        .rate-value {
            font-weight: bold;
            color: #198754;
        }

        .calculate-btn {
            height: 55px;
            border-radius: 10px;
            font-size: 18px;
            font-weight: bold;
        }

        .footer {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            color: #777;
            font-size: 14px;
        }

        @media (max-width: 576px) {

            .header {
                padding: 25px 15px;
            }

            .header h1 {
                font-size: 25px;
            }

            .content {
                padding: 25px 20px;
            }

            .rate-item {
                flex-direction: column;
                gap: 5px;
            }
        }

    </style>

</head>

<body>

<div class="main-container">

    <div class="calculator-card">

        <!-- Header -->

        <div class="header">

            <div class="header-icon">
                ⚡
            </div>

            <h1>
                Electricity Bill Calculator
            </h1>

            <p>
                JSP Web Application
            </p>

        </div>


        <!-- Main Content -->

        <div class="content">

            <div class="row g-4">

                <!-- Input Section -->

                <div class="col-md-6">

                    <h4 class="mb-4">
                        Calculate Your Bill
                    </h4>

                    <form action="calculate" method="post">

                        <div class="mb-4">

                            <label
                                for="units"
                                class="form-label">

                                Enter Electricity Units

                            </label>

                            <input
                                type="number"
                                id="units"
                                name="units"
                                class="form-control"
                                placeholder="e.g. 150"
                                min="0"
                                step="0.01"
                                required>

                            <div class="form-text">
                                Enter the total units consumed.
                            </div>

                        </div>


                        <div class="d-grid">

                            <button
                                type="submit"
                                class="btn btn-primary calculate-btn">

                                Calculate Bill

                            </button>

                        </div>

                    </form>

                </div>


                <!-- Rate Section -->

                <div class="col-md-6">

                    <div class="rate-box">

                        <h4>
                            Electricity Rates
                        </h4>

                        <div class="rate-item">

                            <span class="rate-name">
                                First 50 units
                            </span>

                            <span class="rate-value">
                                ₹3.50 / unit
                            </span>

                        </div>

                        <div class="rate-item">

                            <span class="rate-name">
                                Next 100 units
                            </span>

                            <span class="rate-value">
                                ₹4.00 / unit
                            </span>

                        </div>

                        <div class="rate-item">

                            <span class="rate-name">
                                Next 100 units
                            </span>

                            <span class="rate-value">
                                ₹5.20 / unit
                            </span>

                        </div>

                        <div class="rate-item">

                            <span class="rate-name">
                                Above 250 units
                            </span>

                            <span class="rate-value">
                                ₹6.50 / unit
                            </span>

                        </div>

                    </div>

                </div>

            </div>

        </div>


        <!-- Footer -->

        <div class="footer">

            Electricity Bill Calculator • Developed using JSP

        </div>

    </div>

</div>

</body>

</html>