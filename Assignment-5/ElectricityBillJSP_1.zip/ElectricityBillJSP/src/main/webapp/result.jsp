<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Electricity Bill Result</title>

    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
        rel="stylesheet">

    <style>

        body {
            background: #f2f5f9;
        }

        .result-card {
            max-width: 600px;
            margin: 80px auto;
        }

        .bill-amount {
            font-size: 42px;
            font-weight: bold;
        }

    </style>

</head>

<body>

<div class="container">

    <div class="card shadow result-card">

        <div class="card-header bg-success text-white text-center">

            <h2>Electricity Bill</h2>

        </div>

        <div class="card-body text-center">

            <h5 class="text-muted">
                Electricity Consumption
            </h5>

            <h3>
                <%= request.getAttribute("units") %> Units
            </h3>


            <hr>


            <h5 class="text-muted">
                Total Electricity Bill
            </h5>

            <div class="bill-amount text-success">

                ₹<%= request.getAttribute("bill") %>

            </div>


            <hr>


            <div class="alert alert-success">

                Your electricity bill has been
                calculated successfully.

            </div>


            <a
                href="index.jsp"
                class="btn btn-primary">

                Calculate Another Bill

            </a>

            <button
                onclick="window.print()"
                class="btn btn-secondary">

                Print Bill

            </button>

        </div>

    </div>

</div>

</body>

</html>