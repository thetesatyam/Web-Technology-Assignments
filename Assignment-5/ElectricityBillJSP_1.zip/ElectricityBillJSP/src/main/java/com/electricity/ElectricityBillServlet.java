package com.electricity;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/calculate")
public class ElectricityBillServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Get units from form
        double units = Double.parseDouble(
                request.getParameter("units")
        );

        double bill = 0;

        // Electricity bill calculation

        if (units <= 50) {

            bill = units * 3.50;

        } else if (units <= 150) {

            bill = (50 * 3.50)
                    + ((units - 50) * 4.00);

        } else if (units <= 250) {

            bill = (50 * 3.50)
                    + (100 * 4.00)
                    + ((units - 150) * 5.20);

        } else {

            bill = (50 * 3.50)
                    + (100 * 4.00)
                    + (100 * 5.20)
                    + ((units - 250) * 6.50);
        }

        // Round to 2 decimal places
        bill = Math.round(bill * 100.0) / 100.0;

        // Send values to JSP
        request.setAttribute("units", units);
        request.setAttribute("bill", bill);

        // Forward to result page
        request.getRequestDispatcher("result.jsp")
               .forward(request, response);
    }
}